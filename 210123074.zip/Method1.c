#include <pthread.h>
#include <stdio.h>

#define SIZE 9

int sudoku[SIZE][SIZE];
int results[3*SIZE];

typedef struct {
    int row;
    int col;
} parameters;

void *checkColumn(void *param) {
    parameters *p = (parameters *)param;
    int r = p->row;
    int c = p->col;
    int visited[SIZE] = {0};

    for(int col=c;col<SIZE;col++)
    {
        for (int i = 0; i < SIZE; i++) 
        {
            int num = sudoku[i][col];
            if (num < 1 || num > SIZE || visited[num - 1]) {
                results[col] = 0; 
                printf("Column %d is invalid\n",col+1);
                return NULL;
            }
            visited[num - 1] = 1;
        }
        for(int i=0;i<SIZE;i++)
        {
            visited[i]=0;
        }
        printf("Column %d is valid\n",col+1);
        results[col] = 1;
    }
    
    return NULL;
}

void *checkRow(void *param) {
    parameters *p = (parameters *)param;
    int r = p->row;
    int c = p->col;
    int visited[SIZE] = {0};
    for(int row=r;row<SIZE;row++)
    {
        for (int i = 0; i < SIZE; i++) 
        {
            int num = sudoku[row][i];
            if (num < 1 || num > SIZE || visited[num - 1]) 
            {
                results[SIZE+row] = 0;
                printf("Row %d is invalid\n",row+1);
                return NULL;
            }
            visited[num - 1] = 1;
        }
        for(int i=0;i<SIZE;i++)
        {
            visited[i]=0;
        }
        printf("Row %d is valid\n",row+1);
        
        results[SIZE+row] = 1;
    }
    return NULL;
}

void *checkSubgrid(void *param) {
    parameters *p = (parameters *)param;
    int row = p->row;
    int col = p->col;
    int subgrid = (row) * 3 + (col);
    int visited[SIZE] = {0};

    int startRow = row*3;
    int startCol = col*3;

    for (int i = startRow; i < startRow + 3; i++) {
        for (int j = startCol; j < startCol + 3; j++) {
            int num = sudoku[i][j];
            if (num < 1 || num > SIZE || visited[num - 1]) {
                results[2*SIZE+subgrid] = 0;
                printf("Subgrid %d is invalid\n",subgrid+1);
                return NULL;
            }
            visited[num - 1] = 1;
        }
    }
    printf("Subgrid %d is valid\n",subgrid+1);
    results[2*SIZE+subgrid] = 1;
    return NULL;
}

int main() {

    FILE* file = fopen("week10-ML2-input1.txt","r");
    for(int i=0;i<9;i++)
    {
        for(int j=0;j<9;j++)
        {
            fscanf(file,"%d",&sudoku[i][j]);
        }
    }
    pthread_t threads[SIZE+2]; 
    parameters params[SIZE+2];
    for(int i=0;i<2;i++)
    {
        params[i].row=0;
        params[i].col=0;
    }

    pthread_create(&threads[0],NULL,checkColumn,&params[0]);
    pthread_create(&threads[1],NULL,checkRow,&params[1]);

    // Create threads to check subgrids
    for (int i = 2; i < SIZE+2; i++) {
        int row = (i-2)/3;
        int col = (i-2)%3;
        params[i].row = row;
        params[i].col = col;
        pthread_create(&threads[i], NULL, checkSubgrid, &params[i]);
    }

    // Wait for all threads to complete
    for (int i = 0; i < SIZE+2; i++) {
        pthread_join(threads[i], NULL);
    }

    // Check the results
    int Valid = 1;

    for (int i = 0; i < 3*SIZE; i++) {
        if (results[i]==0) {
            Valid = 0;
            break;
        }
    }

    if (Valid) {
        printf("\n\nSudoku puzzle is valid.\n\n");
    } else {
        printf("\n\nSudoku puzzle is not valid.\n\n");
    }

    return 0;
}

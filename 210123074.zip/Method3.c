#include <pthread.h>
#include <stdio.h>

#define SIZE 9

int sudoku[SIZE][SIZE];
int results[3*SIZE];

typedef struct {
    int row;
    int col;
} parameters;

void *checkColumn(void *param) {
    parameters *p = (parameters *)param;
    int row = p->row;
    int col = p->col;
    int visited[SIZE] = {0};

    for (int i = 0; i < SIZE; i++) {
        int num = sudoku[i][col];
        if (num < 1 || num > SIZE || visited[num - 1]) {
            results[col] = 0; // Set column result to 0 (invalid)
            printf("Column %d is invalid\n",col+1);
            return NULL;
        }
        visited[num - 1] = 1;
    }
    printf("Column %d is valid\n",col+1);
    results[col] = 1; // Set column result to 1 (valid)
    return NULL;
}

void *checkRow(void *param) {
    parameters *p = (parameters *)param;
    int row = p->row;
    int col = p->col;
    int visited[SIZE] = {0};

    for (int i = 0; i < SIZE; i++) {
        int num = sudoku[row][i];
        if (num < 1 || num > SIZE || visited[num - 1]) {
            results[SIZE+row] = 0; // Set row result to 0 (invalid)
            printf("Row %d is invalid\n",row+1);
            return NULL;
        }
        visited[num - 1] = 1;
    }
    printf("Row %d is valid\n",row+1);
    results[SIZE+row] = 1; // Set row result to 1 (valid)
    return NULL;
}

void *checkSubgrid(void *param) {
    parameters *p = (parameters *)param;
    int row = p->row;
    int col = p->col;
    int subgrid = (row) * 3 + (col);
    int visited[SIZE] = {0};

    int startRow = row*3;
    int startCol = col*3;

    for (int i = startRow; i < startRow + 3; i++) {
        for (int j = startCol; j < startCol + 3; j++) {
            int num = sudoku[i][j];
            if (num < 1 || num > SIZE || visited[num - 1]) {
                results[2*SIZE+subgrid] = 0; // Set subgrid result to 0 (invalid)
                printf("Subgrid %d is invalid\n",subgrid+1);
                return NULL;
            }
            visited[num - 1] = 1;
        }
    }
    printf("Subgrid %d is valid\n",subgrid+1);
    results[2*SIZE+subgrid] = 1; // Set subgrid result to 1 (valid)
    return NULL;
}

int main() {
    // Initialize the Sudoku puzzle (sudoku[9][9]) here
    FILE* file = fopen("week10-ML2-input1.txt","r");
    for(int i=0;i<9;i++)
    {
        for(int j=0;j<9;j++)
        {
            fscanf(file,"%d",&sudoku[i][j]);
        }
    }
    pthread_t threads[SIZE * 3]; // 9 columns + 9 rows + 9 subgrids
    parameters params[SIZE * 3];

    // Create threads to check columns
    for (int i = 0; i < SIZE; i++) {
        params[i].row = 0;
        params[i].col = i;
        pthread_create(&threads[i], NULL, checkColumn, &params[i]);
    }

    for(int i=0;i<SIZE;i++)
    {
        pthread_join(threads[i],NULL);
    }
    printf("\n");
    // Create threads to check rows
    for (int i = SIZE; i < SIZE * 2; i++) {
        params[i].row = i-SIZE;
        params[i].col = 0;
        pthread_create(&threads[i], NULL, checkRow, &params[i]);
    }
    for(int i=SIZE;i<2*SIZE;i++)
    {
        pthread_join(threads[i],NULL);
    }
    printf("\n");
    // Create threads to check subgrids
    for (int i = SIZE * 2; i < SIZE * 3; i++) {
        params[i].row = (i - SIZE * 2) / 3;
        params[i].col = (i - SIZE * 2) % 3;
        pthread_create(&threads[i], NULL, checkSubgrid, &params[i]);
    }

    // Wait for all threads to complete
    for (int i = 2*SIZE; i < SIZE * 3; i++) {
        pthread_join(threads[i], NULL);
    }
    printf("\n");
    // Check the results
    int Valid = 1; // Assume puzzle is valid

    for (int i = 0; i < 3*SIZE; i++) {
        if (results[i]==0) {
            Valid = 0; // Puzzle is not valid
            break;
        }
    }

    if (Valid) {
        printf("\n\nSudoku puzzle is valid.\n\n");
    } else {
        printf("\n\nSudoku puzzle is not valid.\n\n");
    }

    return 0;
}
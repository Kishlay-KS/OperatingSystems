#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main() {
    char c;
    char * s;
    int shmid;
    char * data;
    int SHM_SIZE=1024;

    key_t temp_key = ftok("week05-ML2-input.txt", 'R');
    if (temp_key == -1) {
        perror("ftok");
        exit(EXIT_FAILURE);
    }
    FILE* file = fopen("week05-ML2-input.txt","r");
    int n;
    fscanf(file,"%d",&n);
    n++;

    char* arr[n];
    key_t f_id[n];
    key_t key;
    for(int i=0;i<n;i++)
    {
        key = temp_key+i;

        /* connect to (and possibly create) the segment: */
        if ((shmid = shmget(key, SHM_SIZE, 0664 | IPC_CREAT)) == -1) {
            perror("shmget");
            exit(1);
        }
        f_id[i]=shmid;
        arr[i]=shmat(shmid,NULL,0);
        
        /* attach to the segment to get a pointer to it: */
        if (arr[i] == (char *)(-1)) {
            perror("shmat");
            exit(1);
        }

        s=arr[i];
        int k = 0;
        c='a';

        while(c!='\n')
        {
            fscanf(file,"%c",&c);
            *s++=c;
        }
        *s='\0';
    }

    for(int j=0;j<n;j++)
    {
        // printf("%s\n",arr[j]);

        if(shmdt(arr[j])==-1)
        {
            perror("shmdt");
            exit(1);
        }
    }
    return 0;
}
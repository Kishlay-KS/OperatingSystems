#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 1024

// struct ScoreCard {
//     int runs=0;
//     int balls=0;
//     char *b = "*";
//     char * player ="**";
// };

int main() {
    key_t temp_key = ftok("week05-ML2-input.txt", 'R');
    if (temp_key == -1) {
        perror("ftok");
        exit(EXIT_FAILURE);
    }
    // struct ScoreCard players[7];
    // players[0].player = "Gambhir";
    // players[1].player = "Sehwag";
    // players[2].player = "Pujara";
    // players[3].player = "Tendulkar";
    // players[4].player = "Kohli";
    // players[5].player = "Raina";
    // players[6].player = "Dhoni";

    for(int i=1;i<603;i++)
    {
        if(i==602) break;
        key_t key =temp_key+i;
        int shmid = shmget(key,SHM_SIZE,0666);
        // int shmid = shmget(key, SHM_SIZE, 0666);
        if (shmid == -1) {
            printf("Error");
            perror("shmget");
            exit(EXIT_FAILURE);
        }

        char *shm_ptr = shmat(shmid, NULL, 0);
        if (shm_ptr == (char *)-1) {
            perror("shmat");
            exit(EXIT_FAILURE);
        }
        char * comments[4];
        int j=0;
        char * token;
        token = strtok(shm_ptr,",");
        while(token!=NULL)
        {
            comments[j++]=token;
            token = strtok(NULL,",");
        }
        printf("%s",comments[0]);
        printf("%s\n",comments[1]);


        shmdt(shm_ptr);
        shmctl(shmid, IPC_RMID, NULL);
    }

    return 0;
}